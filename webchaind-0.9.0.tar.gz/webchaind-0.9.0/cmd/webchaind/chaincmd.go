// Copyright 2015 The go-ethereum Authors
// Copyright 2018 Webchain project
// This file is part of Webchain.
//
// Webchain is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Webchain is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Webchain. If not, see <http://www.gnu.org/licenses/>.

package main

import (
	"bufio"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/webchain-network/webchaind/common"
	"github.com/webchain-network/webchaind/core"
	"github.com/webchain-network/webchaind/core/state"
	"github.com/webchain-network/webchaind/core/types"
	"github.com/webchain-network/webchaind/logger/glog"
	"gopkg.in/urfave/cli.v1"
)

var (
	importCommand = cli.Command{
		Action: importChain,
		Name:   "import",
		Usage:  `Import a blockchain file`,
	}
	exportCommand = cli.Command{
		Action: exportChain,
		Name:   "export",
		Usage:  `Export blockchain into file`,
		Description: `
	Requires a first argument of the file to write to.
	Optional second and third arguments control the first and
	last block to write. In this mode, the file will be appended
	if already existing.
		`,
	}
	upgradedbCommand = cli.Command{
		Action:  upgradeDB,
		Name:    "upgrade-db",
		Aliases: []string{"upgradedb"},
		Usage:   "Upgrade chainblock database",
	}
	dumpCommand = cli.Command{
		Action: dump,
		Name:   "dump",
		Usage:  `Dump a specific block from storage`,
		Description: `
	The arguments are interpreted as block numbers or hashes.
	Use "$ webchaind dump 0" to dump the genesis block.
		`,
	}
	dumpChainConfigCommand = cli.Command{
		Action:  dumpChainConfig,
		Name:    "dump-chain-config",
		Aliases: []string{"dumpchainconfig"},
		Usage:   "Dump current chain configuration to JSON file [REQUIRED argument: filepath.json]",
		Description: `
	The dump external configuration command writes a JSON file containing pertinent configuration data for
	the configuration of a chain database. It includes genesis block data as well as chain fork settings.
		`,
	}
	rollbackCommand = cli.Command{
		Action:  rollback,
		Name:    "rollback",
		Aliases: []string{"roll-back", "set-head", "sethead"},
		Usage:   "Set current head for blockchain, purging antecedent blocks",
		Description: `
	Rollback set the current head block for block chain already in the database.
	This is a destructive action, purging any block more recent than the index specified.
	Syncing will require downloading contemporary block information from the index onwards.
		`,
	}
	statusCommand = cli.Command{
		Action: status,
		Name:   "status",
		Usage:  "Display the status of the current node",
		Description: `
	Show the status of the current configuration.
		`,
	}
	resetCommand = cli.Command{
		Action: resetChaindata,
		Name:   "reset",
		Usage:  "Reset (remove) the chain database",
		Description: `
		Reset does a hard reset of the entire chain database.
		This is a drastic and irreversible command, and should be used with caution.
		The command will require user confirmation before any action is taken.
		`,
	}
	recoverCommand = cli.Command{
		Action: recoverChaindata,
		Name:   "recover",
		Usage:  "Attempt blockchain data recovery in case of data corruption",
		Description: `
		Recover scans and health-checks all available blockchain data in order
		to recover all consistent and healthy block data. It will remove invalid or
		corrupt block data that may have been caused by hard killing, system failure,
		space limitations, or attack.
		`,
	}
)

func importChain(ctx *cli.Context) error {
	if len(ctx.Args()) != 1 {
		log.Fatal("This command requires an argument.")
	}
	chain, chainDb := MakeChain(ctx)
	start := time.Now()
	err := ImportChain(chain, ctx.Args().First())
	chainDb.Close()
	if err != nil {
		log.Fatal("Import error: ", err)
	}
	fmt.Printf("Import done in %v", time.Since(start))
	return nil
}

func exportChain(ctx *cli.Context) error {
	if len(ctx.Args()) < 1 {
		log.Fatal("This command requires an argument.")
	}
	chain, _ := MakeChain(ctx)
	start := time.Now()

	fp := ctx.Args().First()
	if len(ctx.Args()) < 3 {
		if err := ExportChain(chain, fp); err != nil {
			log.Fatal(err)
		}
	} else {
		// This can be improved to allow for numbers larger than 9223372036854775807
		first, err := strconv.ParseUint(ctx.Args().Get(1), 10, 64)
		if err != nil {
			log.Fatal("export paramater: ", err)
		}
		last, err := strconv.ParseUint(ctx.Args().Get(2), 10, 64)
		if err != nil {
			log.Fatal("export paramater: ", err)
		}
		if err = ExportAppendChain(chain, fp, first, last); err != nil {
			log.Fatal(err)
		}
	}

	fmt.Printf("Export done in %v", time.Since(start))
	return nil
}

func upgradeDB(ctx *cli.Context) error {
	glog.Infoln("Upgrading blockchain database")

	chain, chainDb := MakeChain(ctx)
	bcVersion := core.GetBlockChainVersion(chainDb)
	if bcVersion == 0 {
		bcVersion = core.BlockChainVersion
	}

	// Export the current chain.
	filename := fmt.Sprintf("blockchain_%d_%s.chain", bcVersion, time.Now().Format("20060102_150405"))
	exportFile := filepath.Join(ctx.GlobalString(DataDirFlag.Name), filename)
	if err := ExportChain(chain, exportFile); err != nil {
		log.Fatal("Unable to export chain for reimport ", err)
	}
	chainDb.Close()
	os.RemoveAll(filepath.Join(ctx.GlobalString(DataDirFlag.Name), "chaindata"))

	// Import the chain file.
	chain, chainDb = MakeChain(ctx)
	core.WriteBlockChainVersion(chainDb, core.BlockChainVersion)
	err := ImportChain(chain, exportFile)
	chainDb.Close()
	if err != nil {
		log.Fatalf("Import error %v (a backup is made in %s, use the import command to import it)", err, exportFile)
	} else {
		os.Remove(exportFile)
		glog.Infoln("Import finished")
	}
	return nil
}

// Original use allows n hashes|ints as space-separated arguments, dumping entire state for each block n[x].
// $ webchaind dump [hash|num] [hash|num] ... [hash|num]
// $ webchaind dump 0x234234234234233 42 43 0xlksdf234r23r234223
//
// Revised use allows n hashes|ints as comma-separated first argument and n addresses as comma-separated second argument,
// dumping only state information for given addresses if they're present.
// revised use: $ webchaind dump [hash|num],[hash|num],...,[hash|num] [address],[address],...,[address]
//
// Added unsorted/sorted dumping algorithms.
// unsorted dump is used by default.
// revised use: $ webchaind dump [sorted] [hash|num],[hash|num],...,[hash|num] [address],[address],...,[address]

func dump(ctx *cli.Context) error {

	if ctx.NArg() == 0 {
		return fmt.Errorf("%v: use: $ webchaind dump [blockHash|blockNum],[blockHash|blockNum] [[addressHex|addressPrefixedHex],[addressHex|addressPrefixedHex]]", ErrInvalidFlag)
	}

	firstArg := 0
	sorted := ctx.Args()[0] == "sorted"
	if sorted {
		firstArg = 1
	}

	blocks := strings.Split(ctx.Args()[firstArg], ",")
	addresses := []common.Address{}
	argaddress := ""
	if ctx.NArg() > firstArg+1 {
		argaddress = ctx.Args()[firstArg+1]
	}

	if argaddress != "" {
		argaddresses := strings.Split(argaddress, ",")
		for _, a := range argaddresses {
			addresses = append(addresses, common.HexToAddress(strings.TrimSpace(a)))
		}
	}

	chain, chainDb := MakeChain(ctx)
	defer chainDb.Close()

	prefix := ""
	indent := "    "

	out := bufio.NewWriter(os.Stdout)

	if len(blocks) > 1 {
		prefix = indent
		out.WriteString("[\n")
	}

	for n, b := range blocks {
		b = strings.TrimSpace(b)
		var block *types.Block
		if hashish(b) {
			block = chain.GetBlock(common.HexToHash(b))
		} else {
			num, _ := strconv.Atoi(b)
			block = chain.GetBlockByNumber(uint64(num))
		}
		if block == nil {
			out.WriteString("{}\n")
			log.Fatal("block not found")
		} else {
			state, err := state.New(block.Root(), state.NewDatabase(chainDb))
			if err != nil {
				return fmt.Errorf("could not create new state: %v", err)
			}

			if n != 0 {
				out.WriteString(",\n")
			}

			if sorted {
				err = state.SortedDump(addresses, prefix, indent, out)
			} else {
				err = state.UnsortedDump(addresses, prefix, indent, out)
			}

			if err != nil {
				return err
			}
		}
	}

	if len(blocks) > 1 {
		out.WriteString("\n]")
	}

	out.WriteString("\n")
	out.Flush()

	return nil
}

// hashish returns true for strings that look like hashes.
func hashish(x string) bool {
	_, err := strconv.Atoi(x)
	return err != nil
}
